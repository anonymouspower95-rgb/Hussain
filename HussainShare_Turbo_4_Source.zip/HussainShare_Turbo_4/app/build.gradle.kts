plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hussain.share"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hussain.share"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "4.0 Turbo"
    }

    buildTypes {
        release {
            // Signed with the debug key so the release APK installs directly (no keystore setup needed).
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")
}
