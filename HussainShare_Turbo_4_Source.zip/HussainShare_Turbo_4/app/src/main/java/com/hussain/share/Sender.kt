package com.hussain.share

import android.content.ContentResolver
import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class Sender(
    private val resolver: ContentResolver,
    private val items: List<SendItem>,
    private val stats: Stats,
    private val onReady: () -> Unit,
    private val onFinished: (ok: Boolean, message: String) -> Unit
) {
    private val closed = AtomicBoolean(false)
    private val reported = AtomicBoolean(false)
    private var server: ServerSocketChannel? = null
    private val conns = ConcurrentHashMap.newKeySet<SocketChannel>()
    private val handlers = Executors.newCachedThreadPool()
    private val manifest: ByteArray = buildManifest()

    private fun buildManifest(): ByteArray {
        val bos = ByteArrayOutputStream()
        val d = DataOutputStream(bos)
        d.writeInt(Proto.MAGIC)
        d.writeInt(items.size)
        items.forEach {
            d.writeUTF(it.name.takeLast(200))
            d.writeLong(it.size)
        }
        d.flush()
        return bos.toByteArray()
    }

    fun start() {
        thread(name = "hs-send-accept") {
            try {
                val ss = ServerSocketChannel.open()
                ss.socket().reuseAddress = true
                ss.socket().receiveBufferSize = Proto.SOCK_BUFFER
                ss.socket().bind(InetSocketAddress(Proto.PORT), 16)
                server = ss
                onReady()
                while (!closed.get()) {
                    val ch = ss.accept()
                    conns.add(ch)
                    handlers.execute { handle(ch) }
                }
            } catch (e: Exception) {
                if (!closed.get()) report(false, "Sender start error: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun stop() {
        if (!closed.compareAndSet(false, true)) return
        try { server?.close() } catch (_: Exception) {}
        conns.forEach { try { it.close() } catch (_: Exception) {} }
        handlers.shutdownNow()
    }

    private fun report(ok: Boolean, msg: String) {
        if (reported.compareAndSet(false, true)) {
            stop()
            onFinished(ok, msg)
        }
    }

    private fun handle(ch: SocketChannel) {
        val open = HashMap<Int, FileChannel>()
        try {
            ch.configureBlocking(true)
            ch.socket().tcpNoDelay = true
            ch.socket().sendBufferSize = Proto.SOCK_BUFFER
            val hdr = ByteBuffer.allocate(Proto.REQ_SIZE)
            val buf = ByteBuffer.allocateDirect(Proto.IO_BUFFER)
            while (!closed.get()) {
                hdr.clear()
                if (ch.read(hdr) < 0) break          // clean close between requests
                Proto.readFully(ch, hdr)
                hdr.flip()
                val type = hdr.get()
                val idx = hdr.getInt()
                val off = hdr.getLong()
                val len = hdr.getLong()
                if (type == Proto.REQ_MANIFEST) {
                    sendManifest(ch)
                } else if (type == Proto.REQ_CHUNK) {
                    sendChunk(ch, idx, off, len, open, buf)
                } else if (type == Proto.REQ_DONE) {
                    report(true, "✅ Transfer complete! Receiver ke Downloads/HussainShare mein files save hain.")
                    break
                } else {
                    throw IOException("Bad request")
                }
            }
        } catch (e: Exception) {
            if (!closed.get()) report(false, "Send error: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            open.values.forEach { try { it.close() } catch (_: Exception) {} }
            try { ch.close() } catch (_: Exception) {}
            conns.remove(ch)
        }
    }

    private fun sendManifest(ch: SocketChannel) {
        val b = ByteBuffer.allocate(4 + manifest.size)
        b.putInt(manifest.size)
        b.put(manifest)
        b.flip()
        Proto.writeFully(ch, b)
    }

    private fun sendChunk(
        ch: SocketChannel, idx: Int, off: Long, len: Long,
        open: HashMap<Int, FileChannel>, buf: ByteBuffer
    ) {
        if (idx !in items.indices || off < 0 || len <= 0 || len > Proto.CHUNK_SIZE || off + len > items[idx].size) {
            throw IOException("Invalid chunk request")
        }
        val item = items[idx]
        stats.markStart()
        stats.label = "Sending: ${item.name}"
        val fc = open.getOrPut(idx) {
            val pfd = resolver.openFileDescriptor(item.uri, "r")
                ?: throw IOException("File read nahi hui: ${item.name}")
            ParcelFileDescriptor.AutoCloseInputStream(pfd).channel
        }
        var pos = off
        var left = len
        while (left > 0) {
            buf.clear()
            if (left < buf.capacity()) buf.limit(left.toInt())
            val n = fc.read(buf, pos)
            if (n < 0) throw IOException("File chhoti nikli: ${item.name}")
            buf.flip()
            Proto.writeFully(ch, buf)
            pos += n
            left -= n
            stats.done.addAndGet(n.toLong())
        }
    }
}
