package com.hussain.share

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.channels.SocketChannel
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

class Receiver(
    private val context: Context,
    private val host: String,
    private val stats: Stats,
    private val onStart: (fileCount: Int, total: Long) -> Unit,
    private val onFinished: (ok: Boolean, message: String) -> Unit
) {
    private class Chunk(val idx: Int, val off: Long, val len: Long)

    private val resolver = context.contentResolver
    private val cancelled = AtomicBoolean(false)
    private val failure = AtomicReference<Throwable?>(null)
    private val conns = ConcurrentLinkedQueue<SocketChannel>()
    private val queue = ConcurrentLinkedQueue<Chunk>()
    private var dests: List<Dest> = emptyList()

    fun start() {
        thread(name = "hs-recv") { execute() }
    }

    fun cancel() {
        cancelled.set(true)
        closeAll()
    }

    private fun closeAll() {
        conns.forEach { try { it.close() } catch (_: Exception) {} }
    }

    private fun fail(e: Throwable) {
        if (failure.compareAndSet(null, e)) closeAll()
    }

    private fun connect(): SocketChannel {
        val ch = SocketChannel.open()
        conns.add(ch)
        ch.socket().receiveBufferSize = Proto.SOCK_BUFFER
        ch.socket().tcpNoDelay = true
        ch.socket().connect(InetSocketAddress(host, Proto.PORT), 12000)
        return ch
    }

    private fun execute() {
        try {
            val first = connect()
            Proto.writeFully(first, Proto.request(Proto.REQ_MANIFEST, 0, 0, 0))
            val lenBuf = ByteBuffer.allocate(4)
            Proto.readFully(first, lenBuf)
            lenBuf.flip()
            val mlen = lenBuf.getInt()
            if (mlen < 8 || mlen > 8 * 1024 * 1024) {
                throw IOException("Sender ka version alag hai. Dono phones par Turbo 4.0 install karein.")
            }
            val mb = ByteBuffer.allocate(mlen)
            Proto.readFully(first, mb)
            val din = DataInputStream(ByteArrayInputStream(mb.array()))
            if (din.readInt() != Proto.MAGIC) throw IOException("Sender ka version alag hai. Dono phones par Turbo 4.0 install karein.")
            val count = din.readInt()
            if (count < 1 || count > Proto.MAX_FILES) throw IOException("Invalid file list")
            val metas = ArrayList<FileMeta>()
            repeat(count) {
                val n = din.readUTF()
                val s = din.readLong()
                if (s < 0) throw IOException("Invalid file size")
                metas.add(FileMeta(sanitize(n), s))
            }

            val list = metas.map { Dest(it.name, it.size) }
            dests = list
            val total = metas.sumOf { it.size }
            stats.total = total
            onStart(count, total)

            list.forEach { if (it.size == 0L) { it.open(); it.finish() } }
            metas.forEachIndexed { idx, m ->
                var off = 0L
                while (off < m.size) {
                    val len = minOf(Proto.CHUNK_SIZE, m.size - off)
                    queue.add(Chunk(idx, off, len))
                    off += len
                }
            }
            stats.markStart()

            val streams = maxOf(1, minOf(Proto.STREAMS, queue.size))
            val threads = (0 until streams).map { i ->
                thread(name = "hs-recv-$i") {
                    try {
                        worker(if (i == 0) first else connect())
                    } catch (e: Throwable) {
                        fail(e)
                    }
                }
            }
            threads.forEach { it.join() }

            failure.get()?.let { throw it }
            if (cancelled.get()) throw IOException("Cancelled")

            try { Proto.writeFully(first, Proto.request(Proto.REQ_DONE, 0, 0, 0)) } catch (_: Exception) {}
            onFinished(true, "✅ $count file(s) receive ho gayin. Downloads/HussainShare folder check karein.")
        } catch (e: Throwable) {
            dests.forEach { it.abort() }
            val msg = if (cancelled.get()) "Transfer cancel kar diya gaya."
            else "Receive error: ${failure.get()?.message ?: e.message ?: e.javaClass.simpleName}"
            onFinished(false, msg)
        } finally {
            closeAll()
        }
    }

    private fun worker(conn: SocketChannel) {
        val buf = ByteBuffer.allocateDirect(Proto.IO_BUFFER)
        while (failure.get() == null && !cancelled.get()) {
            val c = queue.poll() ?: break
            val dest = dests[c.idx]
            stats.label = "Receiving: ${dest.name}"
            Proto.writeFully(conn, Proto.request(Proto.REQ_CHUNK, c.idx, c.off, c.len))
            val fc = dest.open()
            var pos = c.off
            var left = c.len
            while (left > 0) {
                buf.clear()
                if (left < buf.capacity()) buf.limit(left.toInt())
                val n = conn.read(buf)
                if (n < 0) throw IOException("${dest.name} incomplete receive hui")
                buf.flip()
                while (buf.hasRemaining()) pos += fc.write(buf, pos)
                left -= n
                stats.done.addAndGet(n.toLong())
            }
            if (dest.remaining.addAndGet(-c.len) == 0L) dest.finish()
        }
    }

    private fun sanitize(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().trimStart('.')
        return if (s.isEmpty()) "file" else s
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
            i++
        }
        return f
    }

    /** One output file; opened lazily, written at arbitrary offsets by several streams. */
    private inner class Dest(val name: String, val size: Long) {
        val remaining = AtomicLong(size)
        private var chan: FileChannel? = null
        private var uri: Uri? = null
        private var file: File? = null
        private var closed = false

        @Synchronized
        fun open(): FileChannel {
            chan?.let { return it }
            val ch: FileChannel
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mimeOf(name))
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HussainShare")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val u = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("Downloads folder create nahi hua")
                uri = u
                val pfd = resolver.openFileDescriptor(u, "rw") ?: throw IOException("File save nahi hui")
                ch = ParcelFileDescriptor.AutoCloseOutputStream(pfd).channel
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "HussainShare")
                dir.mkdirs()
                val f = uniqueFile(dir, name)
                file = f
                ch = RandomAccessFile(f, "rw").channel
            }
            chan = ch
            return ch
        }

        @Synchronized
        fun finish() {
            if (closed) return
            closed = true
            try { chan?.close() } catch (_: Exception) {}
            val u = uri
            if (u != null) {
                try {
                    val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                    resolver.update(u, done, null, null)
                } catch (_: Exception) {}
            }
            val f = file
            if (f != null) {
                try { MediaScannerConnection.scanFile(context, arrayOf(f.absolutePath), null, null) } catch (_: Exception) {}
            }
        }

        @Synchronized
        fun abort() {
            if (closed) return
            closed = true
            try { chan?.close() } catch (_: Exception) {}
            val u = uri
            if (u != null) { try { resolver.delete(u, null, null) } catch (_: Exception) {} }
            file?.let { try { it.delete() } catch (_: Exception) {} }
        }
    }
}
