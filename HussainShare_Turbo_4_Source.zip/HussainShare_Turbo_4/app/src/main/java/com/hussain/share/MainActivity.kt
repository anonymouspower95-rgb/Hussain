package com.hussain.share

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.BitmapShader
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.integration.android.IntentIntegrator
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale

class MainActivity : Activity() {

    // ---- palette ----
    private val cBg = Color.parseColor("#070D1A")
    private val cBg2 = Color.parseColor("#0D1B3A")
    private val cCard = Color.parseColor("#111E38")
    private val cStroke = Color.parseColor("#22365C")
    private val cText = Color.parseColor("#E8F0FB")
    private val cMuted = Color.parseColor("#8FA3C2")
    private val cCyan = Color.parseColor("#38BDF8")
    private val cBlue = Color.parseColor("#2563EB")
    private val cGreen = Color.parseColor("#10B981")
    private val cTeal = Color.parseColor("#14B8A6")
    private val cViolet = Color.parseColor("#8B5CF6")
    private val cPink = Color.parseColor("#EC4899")
    private val cOrange = Color.parseColor("#F59E0B")
    private val cRed = Color.parseColor("#EF4444")

    private val MB = 1024.0 * 1024.0
    private val ui = Handler(Looper.getMainLooper())

    // ---- state ----
    private val items = ArrayList<SendItem>()
    private var sender: Sender? = null
    private var receiver: Receiver? = null
    private var stats: Stats? = null
    private var active = false
    private var transferId = 0
    private var pendingHost: String? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var lastDone = 0L
    private var lastTick = 0L
    private var ema = 0.0
    private var peak = 0.0

    // ---- views ----
    private lateinit var tabSend: TextView
    private lateinit var tabRecv: TextView
    private lateinit var sendPanel: LinearLayout
    private lateinit var receivePanel: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var summaryText: TextView
    private lateinit var sendBtn: Button
    private lateinit var qrCard: LinearLayout
    private lateinit var qrImage: ImageView
    private lateinit var qrIpText: TextView
    private lateinit var ipInput: EditText
    private lateinit var speedText: TextView
    private lateinit var subSpeed: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var percentText: TextView
    private lateinit var etaText: TextView
    private lateinit var fileText: TextView
    private lateinit var statusText: TextView
    private lateinit var cancelBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        makeUi()
        ipInput.setText(getSharedPreferences("hs", Context.MODE_PRIVATE).getString("last_ip", "") ?: "")
        showTab(true)
        refreshList()
    }

    // =====================================================================================
    // UI
    // =====================================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun gradient(c1: Int, c2: Int, r: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
            cornerRadius = dp(r).toFloat()
        }

    private fun ripple(bg: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, null)

    private fun lp(h: Int = -2, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(top) }

    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cCard, 18, cStroke)
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun bigButton(label: String, c1: Int, c2: Int): Button = Button(this).apply {
        text = label
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = ripple(gradient(c1, c2, 14))
        stateListAnimator = null
        minHeight = dp(50)
        minimumHeight = dp(50)
    }

    private fun makeUi() {
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(28))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBg, cBg2))
            addView(page, ViewGroup.LayoutParams(-1, -2))
        }
        scroll.setOnApplyWindowInsetsListener { _, ins ->
            page.setPadding(
                dp(16) + ins.systemWindowInsetLeft, dp(14) + ins.systemWindowInsetTop,
                dp(16) + ins.systemWindowInsetRight, dp(28) + ins.systemWindowInsetBottom
            )
            ins
        }

        // ---- header ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cCard, 20, cStroke)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        header.addView(ImageView(this).apply {
            setImageBitmap(circularProfile())
            contentDescription = "Hussain profile photo"
        }, LinearLayout.LayoutParams(dp(60), dp(60)).apply { rightMargin = dp(14) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(txt("HUSSAIN SHARE", 24f, cCyan, true).apply {
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.05f
        })
        titles.addView(txt("TURBO 4.0  •  MULTI-STREAM  •  OFFLINE", 10.5f, Color.parseColor("#34D399"), true))
        header.addView(titles)
        page.addView(header, lp())

        // ---- marquee ----
        val marquee = TextView(this).apply {
            text = "✦  HUSSAIN NE BANAYA HAI  ✦     •     HUSSAIN NE BANAYA HAI  ✦     •     "
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isSelected = true
            gravity = Gravity.CENTER_VERTICAL
            background = gradient(Color.parseColor("#1B3A66"), Color.parseColor("#3B2A7A"), 12)
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }
        page.addView(marquee, lp(top = 10))

        // ---- tabs ----
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Color.parseColor("#0F1A30"), 16, cStroke)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        tabSend = tabLabel("⬆  SEND") { showTab(true) }
        tabRecv = tabLabel("⬇  RECEIVE") { showTab(false) }
        tabs.addView(tabSend, LinearLayout.LayoutParams(0, dp(44), 1f))
        tabs.addView(tabRecv, LinearLayout.LayoutParams(0, dp(44), 1f))
        page.addView(tabs, lp(top = 14))

        // ---- send panel ----
        sendPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles.addView(tile("🖼", "PHOTOS", cBlue, cCyan, "image/*"), tileLp())
        tiles.addView(tile("🎬", "VIDEOS", cViolet, cPink, "video/*"), tileLp())
        tiles.addView(tile("📁", "FILES / APK", cGreen, cTeal, "*/*"), tileLp())
        sendPanel.addView(tiles, lp(top = 12))

        val listCard = card()
        val listHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        summaryText = txt("", 13f, cMuted, true)
        listHead.addView(summaryText, LinearLayout.LayoutParams(0, -2, 1f))
        listHead.addView(txt("CLEAR", 12f, cOrange, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { if (!active) { items.clear(); refreshList() } }
        })
        listCard.addView(listHead)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCard.addView(listBox, lp(top = 6))
        sendPanel.addView(listCard, lp(top = 10))

        sendBtn = bigButton("⚡  START SENDING + SHOW QR", cGreen, cCyan)
        sendBtn.setOnClickListener { startSending() }
        sendPanel.addView(sendBtn, lp(top = 10))

        qrCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Color.WHITE, 20)
            setPadding(dp(14), dp(14), dp(14), dp(12))
            visibility = View.GONE
        }
        qrImage = ImageView(this).apply { adjustViewBounds = true }
        qrCard.addView(qrImage, LinearLayout.LayoutParams(dp(220), dp(220)))
        qrIpText = txt("", 14f, Color.parseColor("#0B1630"), true).apply { gravity = Gravity.CENTER }
        qrCard.addView(qrIpText, lp(top = 8))
        sendPanel.addView(qrCard, lp(top = 10).apply { gravity = Gravity.CENTER })
        page.addView(sendPanel, lp())

        // ---- receive panel ----
        receivePanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rc = card()
        val scanBtn = bigButton("📷  SCAN QR TO RECEIVE", cBlue, cViolet)
        scanBtn.setOnClickListener {
            IntentIntegrator(this).setPrompt("Sender ka Hussain Share QR scan karein")
                .setBeepEnabled(false).setOrientationLocked(false).initiateScan()
        }
        rc.addView(scanBtn, lp())
        rc.addView(txt("ya sender ka IP likhein", 12f, cMuted).apply { gravity = Gravity.CENTER }, lp(top = 14))
        ipInput = EditText(this).apply {
            hint = "192.168.43.1"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(cMuted)
            gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#0B1630"), 12, cStroke)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        rc.addView(ipInput, lp(top = 6))
        val manualBtn = bigButton("CONNECT USING IP", Color.parseColor("#3B5278"), Color.parseColor("#4B6491"))
        manualBtn.setOnClickListener {
            val host = ipInput.text.toString().trim()
            if (host.isNotEmpty()) receiveFrom(host) else statusText.text = "Sender ka IP likhein ya QR scan karein."
        }
        rc.addView(manualBtn, lp(top = 10))
        receivePanel.addView(rc, lp(top = 12))
        page.addView(receivePanel, lp())

        // ---- live progress card ----
        val pc = card()
        speedText = txt("0.0 MB/s", 38f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        pc.addView(speedText, lp())
        subSpeed = txt("Speed live yahan dikhegi", 12f, Color.parseColor("#34D399"), true).apply { gravity = Gravity.CENTER }
        pc.addView(subSpeed, lp())

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
            isIndeterminate = false
            val track = rounded(Color.parseColor("#1B2A47"), 6)
            val fill = ClipDrawable(gradient(cCyan, cGreen, 6), Gravity.LEFT, ClipDrawable.HORIZONTAL)
            val layers = LayerDrawable(arrayOf<Drawable>(track, fill))
            layers.setId(0, android.R.id.background)
            layers.setId(1, android.R.id.progress)
            progressDrawable = layers
        }
        pc.addView(progressBar, lp(dp(10), 12))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        percentText = txt("0%", 13f, cText, true)
        etaText = txt("ETA --", 13f, cMuted, true).apply { gravity = Gravity.END }
        row.addView(percentText, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(etaText, LinearLayout.LayoutParams(0, -2, 1f))
        pc.addView(row, lp(top = 6))

        fileText = txt("", 12f, cMuted).apply {
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        pc.addView(fileText, lp(top = 4))
        statusText = txt(
            "Dono phones ko same Wi-Fi / hotspot par connect karein. Transfer ke liye internet zaroori nahi.",
            13f, cText
        ).apply { gravity = Gravity.CENTER }
        pc.addView(statusText, lp(top = 10))

        cancelBtn = bigButton("✕  CANCEL TRANSFER", Color.parseColor("#B91C1C"), cRed).apply { visibility = View.GONE }
        cancelBtn.setOnClickListener { cancelTransfer() }
        pc.addView(cancelBtn, lp(top = 10))
        page.addView(pc, lp(top = 14))

        // ---- footer ----
        page.addView(txt(
            "TURBO TIPS\n" +
                "• 5 GHz Wi-Fi router ya 5 GHz hotspot use karein, phones paas rakhein.\n" +
                "• 4 parallel streams + 16 MB chunks + zero-wait disk writes.\n" +
                "• 50 MB/s sirf ideal network par mumkin hai, guaranteed nahi.\n" +
                "• Transfer ke dauran app khula rakhein; screen on rahegi.\n\n" +
                "No ads  •  No account  •  No internet needed",
            11.5f, cMuted
        ).apply { setPadding(dp(6), dp(16), dp(6), 0) }, lp())

        setContentView(scroll)
    }

    private fun tabLabel(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun showTab(send: Boolean) {
        sendPanel.visibility = if (send) View.VISIBLE else View.GONE
        receivePanel.visibility = if (send) View.GONE else View.VISIBLE
        styleTab(tabSend, send)
        styleTab(tabRecv, !send)
    }

    private fun styleTab(t: TextView, on: Boolean) {
        t.background = if (on) gradient(cBlue, cViolet, 12) else null
        t.setTextColor(if (on) Color.WHITE else cMuted)
    }

    private fun tileLp() = LinearLayout.LayoutParams(0, dp(86), 1f).apply {
        leftMargin = dp(4)
        rightMargin = dp(4)
    }

    private fun tile(emoji: String, label: String, c1: Int, c2: Int, mime: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = ripple(gradient(c1, c2, 16))
            isClickable = true
            setOnClickListener { pickFiles(mime) }
        }
        box.addView(TextView(this).apply { text = emoji; textSize = 26f; gravity = Gravity.CENTER })
        box.addView(txt(label, 11.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        return box
    }

    private fun refreshList() {
        listBox.removeAllViews()
        if (items.isEmpty()) {
            summaryText.text = "Koi file select nahi hui"
            listBox.addView(txt("Upar se Photos, Videos ya Files choose karein. Aap alag categories se mix bhi kar sakte hain.", 12f, cMuted))
            return
        }
        summaryText.text = "${items.size} file(s)  •  ${human(items.sumOf { it.size })}"
        val shown = items.take(40)
        shown.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            row.addView(txt(item.name, 13f, cText).apply {
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.MIDDLE
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(txt(human(item.size), 12f, cMuted).apply { setPadding(dp(8), 0, dp(8), 0) })
            row.addView(txt("✕", 15f, cRed, true).apply {
                setPadding(dp(10), dp(4), dp(6), dp(4))
                setOnClickListener { if (!active) { items.remove(item); refreshList() } }
            })
            listBox.addView(row)
        }
        if (items.size > shown.size) listBox.addView(txt("+ ${items.size - shown.size} aur files...", 12f, cMuted))
    }

    // =====================================================================================
    // File picking
    // =====================================================================================

    private fun pickFiles(mime: String) {
        if (active) { statusText.text = "Transfer chal raha hai; pehle usay mukammal ya cancel karein."; return }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 101)
    }

    @Deprecated("Legacy picker callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK && data != null) {
            val incoming = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) {
                for (n in 0 until clip.itemCount) incoming.add(clip.getItemAt(n).uri)
            } else {
                data.data?.let { incoming.add(it) }
            }
            var bad = 0
            incoming.forEach { uri ->
                if (items.any { it.uri == uri }) return@forEach
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val size = sizeOf(uri)
                if (size < 0) bad++ else items.add(SendItem(uri, nameOf(uri), size))
            }
            refreshList()
            statusText.text = if (bad > 0) "$bad file ka size read nahi hua (cloud/virtual file); usay skip kiya gaya."
            else "${items.size} file(s) selected. Aap mazeed categories se bhi add kar sakte hain."
        } else if (requestCode == IntentIntegrator.REQUEST_CODE && resultCode == RESULT_OK) {
            val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            val raw = result?.contents ?: return
            val host = raw.removePrefix("hussainshare://").substringBefore(":").trim()
            if (host.isNotEmpty()) {
                ipInput.setText(host)
                receiveFrom(host)
            }
        }
    }

    // =====================================================================================
    // Transfer control
    // =====================================================================================

    private fun startSending() {
        if (active) { statusText.text = "Sharing pehle se active hai. Receiver connect karein."; return }
        if (items.isEmpty()) { statusText.text = "Pehle Photos, Videos ya Files select karein."; return }
        val token = beginTransfer("Sender start ho raha hai...")
        sendBtn.text = "WAITING FOR RECEIVER..."
        val st = Stats().apply { total = items.sumOf { it.size } }
        stats = st
        val s = Sender(
            contentResolver, items.toList(), st,
            onReady = {
                runOnUiThread {
                    if (token == transferId && active) {
                        val ip = localIp()
                        qrImage.setImageBitmap(makeQr("hussainshare://$ip:${Proto.PORT}"))
                        qrIpText.text = "IP: $ip   •   Port: ${Proto.PORT}"
                        qrCard.visibility = View.VISIBLE
                        statusText.text = "SENDER READY\nReceiver QR scan kare ya IP enter kare."
                    }
                }
            },
            onFinished = { ok, msg -> runOnUiThread { endTransfer(token, ok, msg) } }
        )
        sender = s
        s.start()
    }

    private fun receiveFrom(host: String) {
        if (active) { statusText.text = "Transfer pehle se chal raha hai."; return }
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingHost = host
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 202)
            return
        }
        getSharedPreferences("hs", Context.MODE_PRIVATE).edit().putString("last_ip", host).apply()
        val token = beginTransfer("Connecting to $host:${Proto.PORT} ...")
        val st = Stats()
        stats = st
        val r = Receiver(
            applicationContext, host, st,
            onStart = { n, total -> runOnUiThread { if (token == transferId) statusText.text = "$n file(s)  •  ${human(total)} receive ho rahi hain" } },
            onFinished = { ok, msg -> runOnUiThread { endTransfer(token, ok, msg) } }
        )
        receiver = r
        r.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 202) {
            val host = pendingHost
            pendingHost = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && host != null) {
                receiveFrom(host)
            } else {
                statusText.text = "Files save karne ke liye Storage permission zaroori hai."
            }
        }
    }

    private fun beginTransfer(msg: String): Int {
        transferId++
        active = true
        lastDone = 0L; lastTick = 0L; ema = 0.0; peak = 0.0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        acquireLocks()
        cancelBtn.visibility = View.VISIBLE
        progressBar.progress = 0
        percentText.text = "0%"
        etaText.text = "ETA --"
        speedText.text = "0.0 MB/s"
        subSpeed.text = "Connection ka intezar..."
        fileText.text = ""
        statusText.text = msg
        ui.removeCallbacks(ticker)
        ui.post(ticker)
        return transferId
    }

    private fun endTransfer(token: Int, ok: Boolean, msg: String) {
        if (token != transferId || !active) return
        active = false
        ui.removeCallbacks(ticker)
        sender?.stop(); sender = null
        receiver = null
        releaseLocks()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cancelBtn.visibility = View.GONE
        qrCard.visibility = View.GONE
        sendBtn.text = "⚡  START SENDING + SHOW QR"
        val st = stats
        if (ok && st != null && st.startNanos != 0L) {
            val secs = ((System.nanoTime() - st.startNanos) / 1e9).coerceAtLeast(0.001)
            val avg = st.done.get() / MB / secs
            speedText.text = "${f1(avg)} MB/s"
            subSpeed.text = "Average  •  ${fmtTime(secs.toLong())} mein complete  •  peak ${f1(peak)} MB/s"
            progressBar.progress = 1000
            percentText.text = "100%  •  ${human(st.total)}"
            etaText.text = "Done ✓"
        }
        fileText.text = ""
        statusText.text = msg
    }

    private fun cancelTransfer() {
        if (!active) return
        val token = transferId
        sender?.stop()
        receiver?.cancel()
        endTransfer(token, false, "Transfer cancel kar diya gaya.")
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            renderProgress()
            ui.postDelayed(this, 200)
        }
    }

    private fun renderProgress() {
        val st = stats ?: return
        if (st.startNanos == 0L) return
        val done = st.done.get()
        val total = st.total
        val now = System.nanoTime()
        if (lastTick == 0L) { lastTick = now; lastDone = done }
        val dt = (now - lastTick) / 1e9
        if (dt >= 0.4) {
            val inst = (done - lastDone) / dt / MB
            ema = if (ema == 0.0) inst else ema * 0.5 + inst * 0.5
            if (ema > peak) peak = ema
            lastTick = now
            lastDone = done
        }
        val avg = done / MB / ((now - st.startNanos).coerceAtLeast(1L) / 1e9)
        speedText.text = "${f1(ema)} MB/s"
        subSpeed.text = "≈ ${f1(ema * 8)} Mbps   •   avg ${f1(avg)}   •   peak ${f1(peak)} MB/s"
        if (total > 0) {
            progressBar.progress = ((done * 1000L) / total).toInt().coerceIn(0, 1000)
            percentText.text = "${(done * 100L / total).coerceIn(0L, 100L)}%  •  ${human(done)} / ${human(total)}"
            val left = (total - done).coerceAtLeast(0L)
            etaText.text = if (ema > 0.05) "ETA " + fmtTime(((left / MB) / ema).toLong()) else "ETA --"
        }
        fileText.text = st.label
    }

    // =====================================================================================
    // Helpers
    // =====================================================================================

    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HussainShare:Transfer")
                .apply { setReferenceCounted(false); acquire(60 * 60 * 1000L) }
        } catch (_: Exception) {}
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = wm.createWifiLock(mode, "HussainShare:Wifi").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
    }

    private fun releaseLocks() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Exception) {}
    }

    private fun nameOf(uri: Uri): String {
        var n = "shared_file"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) n = it.getString(0) ?: n
            }
        } catch (_: Exception) {}
        return n.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }

    private fun sizeOf(uri: Uri): Long {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) { val s = it.getLong(0); if (s >= 0) return s }
            }
        } catch (_: Exception) {}
        try {
            contentResolver.openFileDescriptor(uri, "r")?.use { if (it.statSize >= 0) return it.statSize }
        } catch (_: Exception) {}
        return -1
    }

    private fun human(v: Long): String {
        if (v < 0) return "unknown"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var x = v.toDouble()
        var i = 0
        while (x >= 1024 && i < units.lastIndex) { x /= 1024; i++ }
        return String.format(Locale.US, "%.1f %s", x, units[i])
    }

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

    private fun fmtTime(sec: Long): String {
        val s = sec.coerceAtLeast(0L)
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun circularProfile(): Bitmap {
        val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
        val original = BitmapFactory.decodeResource(resources, R.drawable.hussain_profile, opts)
        val size = minOf(original.width, original.height)
        val square = Bitmap.createBitmap(original, (original.width - size) / 2, (original.height - size) / 2, size, size)
        val out = 260
        val output = Bitmap.createBitmap(out, out, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 8f
            color = cCyan
        }
        canvas.drawCircle(out / 2f, out / 2f, out / 2f - 4f, ring)
        val inner = out - 24
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val scaled = Bitmap.createScaledBitmap(square, inner, inner, true)
        paint.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        canvas.save()
        canvas.translate(12f, 12f)
        canvas.drawCircle(inner / 2f, inner / 2f, inner / 2f, paint)
        canvas.restore()
        return output
    }

    private fun makeQr(text: String): Bitmap {
        val n = 600
        val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 1)
        val m = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, n, n, hints)
        val px = IntArray(n * n)
        for (y in 0 until n) for (x in 0 until n) px[y * n + x] = if (m[x, y]) Color.BLACK else Color.WHITE
        return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    /** Prefers the Wi-Fi / hotspot interface over mobile-data ones. */
    private fun localIp(): String {
        var best: String? = null
        var bestScore = Int.MIN_VALUE
        try {
            val all = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            for (ni in all) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase()
                for (a in ni.inetAddresses.toList()) {
                    if (a !is Inet4Address || a.isLoopbackAddress) continue
                    val ip = a.hostAddress ?: continue
                    var score = 0
                    if (a.isSiteLocalAddress) score += 10
                    if (n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth")) score += 5
                    if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("tun") || n.startsWith("dummy")) score -= 20
                    if (score > bestScore) { best = ip; bestScore = score }
                }
            }
        } catch (_: Exception) {}
        return best ?: "Wi-Fi IP check karein"
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        sender?.stop()
        receiver?.cancel()
        releaseLocks()
        super.onDestroy()
    }
}
