package com.hussain.share

import android.net.Uri
import java.io.EOFException
import java.nio.ByteBuffer
import java.nio.channels.ReadableByteChannel
import java.nio.channels.WritableByteChannel
import java.util.concurrent.atomic.AtomicLong

/**
 * HSS4 protocol (Turbo 4.0)
 *
 * Receiver opens N parallel TCP connections to the sender. Every request is a fixed 21-byte header:
 *   type(1) | fileIndex(4) | offset(8) | length(8)
 *   type 1 = MANIFEST -> reply: int length + manifest bytes
 *   type 2 = CHUNK    -> reply: exactly `length` raw bytes of file[fileIndex] starting at `offset`
 *   type 3 = DONE     -> receiver finished; sender can stop
 * Files are cut into 16 MiB chunks that all streams pull in parallel, so big files AND many small
 * files both use every stream, and the disk write overlaps with network reads.
 */
object Proto {
    const val MAGIC = 0x48535334            // "HSS4"
    const val PORT = 8988
    const val REQ_MANIFEST: Byte = 1
    const val REQ_CHUNK: Byte = 2
    const val REQ_DONE: Byte = 3
    const val REQ_SIZE = 21

    const val STREAMS = 4                              // parallel TCP connections
    const val CHUNK_SIZE = 16L * 1024L * 1024L         // work unit per request
    const val IO_BUFFER = 1024 * 1024                  // direct buffer per stream
    const val SOCK_BUFFER = 4 * 1024 * 1024            // kernel socket buffers
    const val MAX_FILES = 5000

    fun readFully(ch: ReadableByteChannel, buf: ByteBuffer) {
        while (buf.hasRemaining()) {
            if (ch.read(buf) < 0) throw EOFException("Connection band ho gaya")
        }
    }

    fun writeFully(ch: WritableByteChannel, buf: ByteBuffer) {
        while (buf.hasRemaining()) ch.write(buf)
    }

    fun request(type: Byte, idx: Int, off: Long, len: Long): ByteBuffer {
        val b = ByteBuffer.allocate(REQ_SIZE)
        b.put(type); b.putInt(idx); b.putLong(off); b.putLong(len)
        b.flip()
        return b
    }
}

class SendItem(val uri: Uri, val name: String, val size: Long)

class FileMeta(val name: String, val size: Long)

/** Shared live counters; the UI reads these on a timer so worker threads never flood the main thread. */
class Stats {
    @Volatile var total: Long = 0
    val done = AtomicLong(0)
    @Volatile var startNanos: Long = 0
    @Volatile var label: String = ""

    @Synchronized
    fun markStart() {
        if (startNanos == 0L) startNanos = System.nanoTime()
    }
}
