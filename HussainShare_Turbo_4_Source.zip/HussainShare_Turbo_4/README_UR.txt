HUSSAIN SHARE TURBO 4.0
=======================

NAYA KYA HAI (3.1 se)
- Naya HSS4 protocol: 4 parallel TCP streams + 16 MB chunks. Bari file aur bohat si chhoti files, dono mein saari streams kaam karti hain.
- Disk write aur network read ek doosre ke saath overlap hote hain (3.1 mein ye baari baari hota tha).
- UI thread ab har read par nahi, har 200 ms par update hota hai -> progress ki wajah se speed kam nahi hoti.
- Wi-Fi low-latency lock + CPU wake lock + screen on, taake transfer ke dauran speed na gire.
- Live speed (MB/s aur Mbps), average, peak, ETA, Cancel button.
- Naya dark UI: Send / Receive tabs, category tiles, file list mein har file ke saamne remove (X), Clear button, QR card.
- Hotspot/Wi-Fi ka sahi IP choose hota hai (mobile data wala IP nahi).
- Android 8/9 par Storage permission, aur Android 15 ke liye edge-to-edge insets fix.
- Adaptive launcher icon. Profile photo + "HUSSAIN NE BANAYA HAI" marquee barqarar.

ZAROORI
- Dono phones par Turbo 4.0 hona chahiye (3.1 / 3.0 ke saath compatible nahi).
- 50 MB/s sirf ideal 5 GHz Wi-Fi par mumkin hai, guaranteed nahi. App network ki limit nahi tor sakti.

APK KAISE BANAYEIN (phone browser se, free)
1. github.com par account banayein, naya repository banayein.
2. Is project ke andar ki saari files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) upload karein.
   Note: .github folder upload hona zaroori hai.
3. Repository mein "Actions" tab kholein -> "Build APK" -> Run workflow (ya push par khud chalta hai).
4. 4-6 minute baad run ke andar "Artifacts" mein HussainShare-Turbo-4-APK download karein (zip mein app-release.apk).
5. APK install karein (Unknown sources allow karni hogi).

APK KAISE BANAYEIN (Android Studio / PC)
- Project folder kholein, JDK 17 + Android SDK 35, phir: Build > Build APK(s)  ya  gradle :app:assembleRelease
- Output: app/build/outputs/apk/release/app-release.apk

SPEED TIPS
- 5 GHz router ya 5 GHz hotspot, phones paas paas.
- Battery saver band rakhein, transfer ke dauran app khula rakhein.
- Kuch hotspots clients ko aapas mein baat nahi karne dete; aisa ho to router ya doosra hotspot try karein.
